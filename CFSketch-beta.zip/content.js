let cfpanel_userData = {};
function runCFPanel(isActive) {
  window.addEventListener("beforeunload", function (e) {
    if (is_recording) {
      cfPanel_recorder.stopRecording();
      chrome.storage.local.set({ screenRecording: false }, function () {
        console.log("Screen Recording is set to false");
      });
    }
  });

  function handleNavigationEvent(e) {
    if (is_recording) {
      stopRecording();
    }
    return true;
  }

  function stopRecording() {
    is_recording = false;
    cfPanel_recorder.stopRecording();
    chrome.storage.local.set({ screenRecording: false }, function () {
      console.log("Screen Recording is set to false");
    });
    console.log("Recording stopped!");
  }

  document.querySelectorAll("#main_content a").forEach(function (link) {
    link.addEventListener("click", handleNavigationEvent);
  });

  window.addEventListener("popstate", function (e) {
    const savedState = { ...window.history.state };
    if (!handleNavigationEvent(e)) {
      history.replaceState(savedState, document.title);
    }
  });

  ["pushState", "replaceState"].forEach(function (method) {
    const original = history[method];
    history[method] = function () {
      if (handleNavigationEvent({ preventDefault: () => {} })) {
        return original.apply(this, arguments);
      }
    };
  });

  const mainHTML = `
    <div id="cfpanel-saving" style="display: none">Saving...</div>
    <div id="cfpanel-header" style="display: none"></div>
    <div id="cfpanel" style="display: none">
      <div id="cfpanel-none-selected" style="display: none">
        <h2>Select or create a new board to get started!</h2>
      </div>

      <div data-id="" id="cfpanel-select-workspace" class="cfpanel-tooltip button" style="margin-right: 20px;">
        <i class="fal fa-sort-circle" style="margin-right: 10px;"></i> <span id="cfpanel-workspace-title">Select a Board</span>
        <span class="cfpanel-tooltiptext">Select Board</span>
      </div>

      <div id="cfpanel-workspaces" style="display:none"></div>

      <div id="cfpanel-board-settings" style="display:none">
        <div class="cfp-option">
          <h4>Name</h4>
          <input class="cfp-board-option" id="cfp-board-name" value="" type="text">
        </div>

        <button id="clearBoard" class="button" style="width: 100%;margin-bottom: 5px;text-align:center">Clear Board</button>
        <button id="cfpanel-delete-board" class="button" style="width: 100%;text-align:center">Delete Board</button>
      </div>

      <button id="newBoard" class="cfpanel-tooltip button-secondary" style="margin-right: 5px">
        <i class="fas fa-plus-square"></i>
        <span class="cfpanel-tooltiptext">New Board</span>
      </button>

      <button id="boardSettings" class="cfpanel-tooltip button-secondary" style="margin-right: 5px">
        <i class="fas fa-cog"></i> 
        <span class="cfpanel-tooltiptext">Board Settings</span>
      </button>

      <div id="cfpanel-drawing-options" style="display: none">
        <div class="cfp-option">
          <h4>Color</h4>
          <button class="button-secondary" id="cfpanel-toggle-brushcolor" style="width: 100%;"><i class="fas fa-circle" style="margin-right: 5px;color: #1e202f"></i> #1e202f</button>
          <input id="cfp-path-color" value="black" type="text" data-coloris style="display:none">
        </div>

        <div class="cfp-option" id="cfp-path-size">
          <h4>Size: (8)</h4>
          <div id="cfp-brush-size">
            <input type="range" min="2" max="10" value="8" class="slider" id="pathSize">
          </div>
        </div>
      </div>

      <div id="cfpanel-main-toolbar">
        <div id="cfpanel-layer-add">
          <button id="toggleDrawingMode" class="cfpanel-tooltip button-secondary">
            <i class="fas fa-paint-brush"></i>
            <span class="cfpanel-tooltiptext">Draw</span>
          </button>

          <a href="#" class="cfpanel-tooltip button-secondary">
            <i class="fas fa-font"></i>
            <span class="cfpanel-tooltiptext">Add Text</span>
          </a>

          <a href="#" class="cfpanel-tooltip button-secondary">
            <i class="fas fa-image"></i>
            <span class="cfpanel-tooltiptext">Add Image</span>
          </a>

          <a href="#" class="cfpanel-tooltip button-secondary" style="display: none">
            <i class="far fa-square"></i>
            <span class="cfpanel-tooltiptext">Add Square</span>
          </a>
          
          <a href="#" class="cfpanel-tooltip button-secondary"  style="display: none">
            <i class="fas fa-external-link"></i>
            <span class="cfpanel-tooltiptext">Add Link</span>
          </a>
        </div>
      </div>

      <div id="cfpanel-edit-toolbar" style="display:none">
        <div id="cfpanel-layer-control">
          <a href="#" class="cfpanel-tooltip button-secondary">
            <i class="fas fa-send-back"></i>
            <span class="cfpanel-tooltiptext">Send to Back</span>
          </a>

          <a href="#" class="cfpanel-tooltip button-secondary">
            <i class="fas fa-send-backward"></i>
            <span class="cfpanel-tooltiptext">Send Backward</span>
          </a>

          <a href="#" class="cfpanel-tooltip button-secondary">
            <i class="fas fa-bring-forward"></i>
            <span class="cfpanel-tooltiptext">Bring Forward</span>
          </a>

          <a href="#" class="cfpanel-tooltip button-secondary">
            <i class="fas fa-bring-front"></i>
            <span class="cfpanel-tooltiptext">Bring to Front</span>
          </a>
        </div>
        <div id="cfpanel-layer-options">
          <a href="#" class="cfpanel-tooltip button-secondary">
            <i class="fas fa-clone"></i>
            <span class="cfpanel-tooltiptext">Duplicate</span>
          </a>

          <a href="#" class="cfpanel-tooltip button-secondary">
            <i class="fas fa-trash"></i>
            <span class="cfpanel-tooltiptext">Remove</span>
          </a>
        </div>
      </div>

      <div id="cfpanel-options-toolbar" style="display:none">
        <div id="cfpanel-image-options" style="display:none">
          <div class="cfp-option">
            <h4>Type</h4>
            <select id="cfpanel-image-type">
              <option value="local">Local</option>
              <option value="url">URL</option>
              <option value="screenshot">Screenshot</option>
            </select>
          </div>
          <div class="cfp-option" id="cfpanel-image-type-local">
            <button class="button-secondary" id="cfpanel-choose-image" style="width:100%;text-align:center">Choose Image</button>
            <span id="cfpanel-image-selected" style="display:none">Image selected</span>
            <input type="file" id="fileInput" style="display:none" />
          </div>
          <div class="cfp-option" id="cfpanel-image-type-url" style="display:none">
            <h4>Image URL</h4>
            <input type="text" id="fileURLInput" />
          </div>
          <div class="cfp-option" id="cfpanel-image-type-screenshot"  style="display:none">
            <h4>Website URL</h4>
            <input type="text" id="websiteURLInput" />
          </div>
          <button class="button" style="display: block;width: 100%" id="cfpanel-uploadImage">Upload</button>
        </div>

      
        <div id="cfpanel-text-options" style="display: none">

          <div class="cfp-option" id="cfp-font-size" style="margin-bottom: 0">
            <h4>Font Size (50)</h4>
            <div id="cfp-font-size">
              <input type="range" min="5" max="150" value="50" class="slider" id="fontSize">
            </div>
          </div>

          <div class="cfp-option" id="cfp-main-color">
            <h4>Text Color</h4>
            <button class="button-secondary" id="cfpanel-toggle-textcolor" style="width: 100%;"><i class="fas fa-circle" style="margin-right: 5px;color: #000"></i> #000</button>
            <input id="cfp-text-color" type="text" data-coloris style="display: none">
          </div>

          <div class="cfp-option">
            <h4>Font</h4>
            
            <div class="cfpanel-group" style="padding: 0;">
              <button class="button-secondary active" id="cfpanel-font-sans">Sans Serif</button>
              <button class="button-secondary" id="cfpanel-font-serif" style="margin-right:0">Serif</button>
            </div>
          </div>

          <div class="cfp-option">
            <h4>Weight</h4>

            <div class="cfpanel-group">
              <button class="button-secondary active" id="cfpanel-weight-normal">Normal</button>
              <button class="button-secondary" id="cfpanel-weight-bold" style="margin-right:0">Bold</button>
            </div>
          </div>

          <div class="cfp-option">
            <h4>Alignment</h4>

            <div class="cfpanel-group">
              <button class="button-secondary active" id="cfpanel-align-left"><i class="fas fa-align-left"></i></button>
              <button class="button-secondary" id="cfpanel-align-center"><i class="fas fa-align-center"></i></button>
              <button class="button-secondary" id="cfpanel-align-right" style="margin-right:0"><i class="fas fa-align-right"></i></button>
            </div>
          </div>

        </div>
      </div>

    </div>

    <div class="cfPanelRecord button" style="display:none"><i class="fas fa-record-vinyl" style="margin-right: 10px;"></i> Record</div>
    <div class="cfPanelDownload button" style="display:none"><i class="fas fa-download" style="margin-right: 10px;"></i> Download WebM</div>
    <div class="closeCFPanel button" style="display:none"><i class="fas fa-times" style="margin-right: 10px;"></i> Close</div>
  `;

  function debounce(func, delay) {
    let timeoutId;
    return function (...args) {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        func(...args);
      }, delay);
    };
  }

  let just_loaded_canvas = false;
  const debouncedSaveToServer = debounce(saveToServer, 3000);

  async function uploadFile() {
    const fileInput = document.getElementById("fileInput");
    const fileURLInput = document.getElementById("fileURLInput");
    const websiteURLInput = document.getElementById("websiteURLInput");

    const data = await fetch("https://app.instantstyleguide.com/cfsketch");
    const json = await data.json();
    const baseUrl = `https://www.filestackapi.com/api/store/S3?key=${json.fs}`;

    if (websiteURLInput.value) {
      document.querySelector("#cfpanel-uploadImage").disabled = true;
      document.querySelector("#cfpanel-uploadImage").textContent =
        "Uploading...";
      const imageURL = `https://api.urlbox.io/v1/${
        json.ub
      }/png?url=${encodeURIComponent(websiteURLInput.value)}`;

      fetch(imageURL)
        .then((response) => {
          if (!response.ok) {
            throw new Error("Failed to load the image.");
          }
          return response.blob();
        })
        .then((imageBlob) => {
          return fetch(baseUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: `url=${imageURL}`,
          });
        })
        .then((response) => response.json())
        .then((data) => handleImageData(data))
        .catch((error) => {
          alert(
            "There was an error uploading your image, make sure it is .png or .jpg and is a valid image. (.svg is not supported)"
          );
          document.querySelector("#cfpanel-uploadImage").disabled = false;
          document.querySelector("#cfpanel-uploadImage").textContent = "Upload";
          console.error("Error:", error);
        });
    } else if (fileURLInput.value) {
      document.querySelector("#cfpanel-uploadImage").disabled = true;
      document.querySelector("#cfpanel-uploadImage").textContent =
        "Uploading...";
      fetch(baseUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: `url=${encodeURIComponent(fileURLInput.value)}`,
      })
        .then((response) => response.json())
        .then((data) => handleImageData(data))
        .catch((error) => {
          alert(
            "There was an error uploading your image, make sure it is .png or .jpg and is a valid image. (.svg is not supported)"
          );
          document.querySelector("#cfpanel-uploadImage").disabled = false;
          document.querySelector("#cfpanel-uploadImage").textContent = "Upload";
          console.error("Error:", error);
        });
    } else if (fileInput.files.length > 0) {
      document.querySelector("#cfpanel-uploadImage").disabled = true;
      document.querySelector("#cfpanel-uploadImage").textContent =
        "Uploading...";
      const file = fileInput.files[0];

      fetch(baseUrl, {
        method: "POST",
        headers: {
          "Content-Type": "image/png",
        },
        body: file,
      })
        .then((response) => response.json())
        .then((data) => handleImageData(data))
        .catch((error) => console.error("Error:", error));
    } else {
      alert("Please provide either a file or a file URL.");
    }

    fileInput.value = "";
    fileURLInput.value = "";
  }

  function handleImageData(data) {
    let activeObject = canvas.getActiveObject();
    const imageUrl = data.url;
    let newItem;
    const viewportCenter = getViewportCenter(canvas);
    fabric.Image.fromURL(imageUrl, function (img) {
      if (activeObject) {
        activeObject.setElement(img.getElement(), { crossOrigin: "anonymous" });
      } else {
        newItem = img.set({
          left: viewportCenter.left,
          top: viewportCenter.top,
          originX: "center",
          originY: "center",
        });
        newItem.set({
          left: newItem.left - (newItem.width * newItem.scaleX) / 2,
          top: newItem.top - (newItem.height * newItem.scaleY) / 2,
        });
        canvas.add(newItem);
        canvas.setActiveObject(img);
      }

      canvas.renderAll();
    });

    document.querySelector("#cfpanel-uploadImage").disabled = false;
    document.querySelector("#cfpanel-uploadImage").textContent = "Upload";
  }

  let is_global_brush = false;
  let brush_color = "#1E202F";
  let brush_size = 8;
  let current_board = null;
  let default_text_color = "#000000";
  let openCFPanel = null;

  let whiteboard = document.createElement("div");
  whiteboard.id = "whiteboard";
  document.body.appendChild(whiteboard);

  let panelLogin = document.createElement("div");
  panelLogin.innerHTML = `<div id="cfpanel-login" style="display: none">
  <h2>CFSketch</h2>
  <p>Login to activate the extension. If no account, your account will be created during beta.</p>
  <input type="email" id="cfpanel-login-email" placeholder="Email">
  <input type="password" id="cfpanel-login-password" placeholder="Password">
  <button class="button" id="cfpanel-login-button">Activate</button>

  <a href="#" target="_blank" style="display: block;text-align: center; padding: 10px; font-size: 16px; text-decoration:underline;margin: 10px 0;">Buy now to get access!</a>

  <button class="button-secondary" id="cfpanel-login-close">Close</button>
</div>`;
  document.body.appendChild(panelLogin);

  document
    .querySelector("#cfpanel-login-close")
    .addEventListener("click", function () {
      document.querySelector("#cfpanel-login").style.display = "none";
      document.querySelector("#whiteboard-underlay").style.display = "none";
    });

  document
    .querySelector("#cfpanel-login-button")
    .addEventListener("click", async function () {
      const email = document.querySelector("#cfpanel-login-email").value;
      const password = document.querySelector("#cfpanel-login-password").value;

      if (email) {
        const response = await fetch(
          "https://app.instantstyleguide.com/cfsketch-activate",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              email: email,
              password: password,
            }),
          }
        );

        if (response.status === 401) {
          alert("Invalid email or password.");
          return;
        }

        const data = await response.json();

        if (data && data.success) {
          const newData = JSON.stringify({
            active: true,
            userData: data.userData,
          });

          chrome.storage.local.set(
            {
              cfSketch_user_data: newData,
            },
            function () {
              alert("Woohoo!! Account activated!");
              isActive = true;
              document.querySelector("#cfpanel-login").style.display = "none";
              openWhiteboard();
            }
          );
        } else {
          alert("Invalid email");
        }
      } else {
        alert("Please enter your email");
      }
    });

  const getBoards = async () => {
    const response = await fetch(
      "https://app.instantstyleguide.com/cfsketch-get-boards",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userData: cfpanel_userData.userData,
        }),
      }
    );

    const output = await response.json();
    return output;
  };

  const getBoard = async (id) => {
    const response = await fetch(
      "https://app.instantstyleguide.com/cfsketch-get-board",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userData: cfpanel_userData.userData,
          id: id,
        }),
      }
    );

    const output = await response.json();
    return output;
  };

  const updateBoard = async (board, data) => {
    const sizeInBytes = new Blob([data]).size;
    if (sizeInBytes > 30 * 1024 * 1024) {
      alert(
        "Sorry, the board is over 30mb and cannot save. Please remove images or create a new board."
      );
      return;
    }
    const response = await fetch(
      "https://app.instantstyleguide.com/cfsketch-update-board",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: board.id,
          name: board.name,
          bgColor: board.bgColor,
          textColor: board.textColor,
          brushColor: board.brushColor,
          data: data,
          userData: cfpanel_userData.userData,
        }),
      }
    );

    const output = await response.json();
    setTimeout(() => {
      document.querySelector("#cfpanel-saving").style.display = "none";
    }, 1000);
    return output;
  };

  const newBoard = async (name, data, bgColor, textColor, brushColor) => {
    const response = await fetch(
      "https://app.instantstyleguide.com/cfsketch-new-board",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: name,
          data: data,
          bgColor: bgColor,
          textColor: textColor,
          brushColor: brushColor,
          userData: cfpanel_userData.userData,
        }),
      }
    );

    const output = await response.json();
    return output;
  };

  const deleteBoard = async (id) => {
    const response = await fetch(
      "https://app.instantstyleguide.com/cfsketch-delete-board",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: id,
          userData: cfpanel_userData.userData,
        }),
      }
    );

    const output = await response.json();
    return output;
  };

  let whiteboardUnderlay = document.createElement("div");
  whiteboardUnderlay.id = "whiteboard-underlay";
  whiteboardUnderlay.style.display = "none";
  document.body.appendChild(whiteboardUnderlay);

  let canvasEl = document.createElement("canvas");
  canvasEl.id = "whiteboard-canvas";
  canvasEl.width = window.innerWidth;
  canvasEl.height = window.innerHeight;
  whiteboard.appendChild(canvasEl);

  let panelNav = document.createElement("div");
  panelNav.innerHTML = mainHTML;
  whiteboard.appendChild(panelNav);

  document
    .querySelector("#cfpanel-uploadImage")
    .addEventListener("click", function () {
      uploadFile();
    });

  chrome.storage.local.get(["openButtonPosition"], function (result) {
    let openButton = document.createElement("div");
    openButton.setAttribute("class", "openCFPanel");
    openButton.innerHTML = `<i class="fas fa-scribble" style="margin-right: 5px;"></i> CFSketch`;

    const data = result.openButtonPosition;
    if (data) {
      openButton.style.left = data;
    }

    document.body.appendChild(openButton);

    let isDragging = false;
    let mouseX;

    openButton.onmousedown = function (e) {
      isDragging = true;
      mouseX = e.clientX;
    };

    document.onmousemove = function (e) {
      if (isDragging) {
        let deltaX = e.clientX - mouseX;
        openButton.style.left = `${openButton.offsetLeft + deltaX}px`;
        mouseX = e.clientX;
      }
    };

    document.onmouseup = function () {
      isDragging = false;
      chrome.storage.local.set({ openButtonPosition: openButton.style.left });
    };

    openCFPanel = document.querySelector(".openCFPanel");

    chrome.storage.local.get(["screenRecording"], function (result) {
      if (result.screenRecording) {
        is_recording = true;
        document.querySelector(
          ".cfPanelRecord"
        ).innerHTML = `<i class="fas fa-circle-stop" style="margin-right: 10px;"></i> Stop Recording`;
        cfPanel_recorder.addWebCamVideo();
      }
    });

    openButton.addEventListener("click", function () {
      if (isActive) {
        openWhiteboard();

        chrome.storage.local.get(["screenRecording"], function (result) {
          if (result.screenRecording) {
            is_recording = true;
            document.querySelector(
              ".cfPanelRecord"
            ).innerHTML = `<i class="fas fa-circle-stop" style="margin-right: 10px;"></i> Stop Recording`;
            cfPanel_recorder.addWebCamVideo();
          } else {
            is_recording = false;
            document.querySelector(
              ".cfPanelRecord"
            ).innerHTML = `<i class="fas fa-record-vinyl" style="margin-right: 10px;"></i> Record`;
          }
        });
      } else {
        document.querySelector("#whiteboard-underlay").style.display = "block";
        document.querySelector("#cfpanel-login").style.display = "block";
      }
    });
  });

  async function openWhiteboard() {
    whiteboardUnderlay.style.display = "block";
    whiteboardUnderlay.style.backgroundColor = "rgba(0,0,0,0.2)";
    whiteboard.style.boxShadow = "10px 0 60px rgba(0,0,0,0.3)";
    document.querySelector(".openCFPanel").style.display = "none";
    panelNav.style.display = "block";
    document.body.style.overflow = "hidden";
    whiteboard.style.top = "0";

    if (!current_board) {
      document.querySelector("#cfpanel-main-toolbar").style.display = "none";
      document.querySelector("#clearBoard").style.display = "none";
      document.querySelector("#boardSettings").style.display = "none";
      document.querySelector("#cfpanel-none-selected").style.display = "block";
    }

    setTimeout(() => {
      whiteboard.querySelector("#cfpanel").style.display = "flex";
      whiteboard.querySelector("#cfpanel-header").style.display = "block";
      document.querySelector(".closeCFPanel").style.display = "inline-block";
      document.querySelector(".cfPanelRecord").style.display = "inline-block";
    }, 550);

    const boards = await getBoards();

    chrome.storage.local.set({
      "cfpanel-the-boards": boards.boards,
    });

    chrome.storage.local.get(
      "cfpanel-saved-positions",
      async function (result) {
        if (result["cfpanel-saved-positions"]) {
          let positions = JSON.parse(result["cfpanel-saved-positions"]);

          const board = await getBoard(positions.board_id);

          if (board.boards[0]) {
            current_board = positions.board_id;
            document.querySelector("#cfpanel-workspace-title").textContent =
              positions.board_name;
            document.querySelector("#cfp-board-name").value =
              positions.board_name;

            document.querySelector("#cfpanel-none-selected").style.display =
              "none";
            document.querySelector("#cfpanel-main-toolbar").style.display =
              "block";
            document.querySelector("#clearBoard").style.display = "block";
            document.querySelector("#boardSettings").style.display = "block";

            canvas.loadFromJSON(board.boards[0].data, function () {
              canvas.setZoom(positions.zoom);
              canvas.relativePan(
                new fabric.Point(
                  positions.left - canvas.viewportTransform[4],
                  positions.top - canvas.viewportTransform[5]
                )
              );

              document
                .querySelector("#cfpanel-select-workspace")
                .setAttribute("data-id", board.boards[0].id);
              canvas.renderAll();
            });
          }
        } else {
          const board = await getBoard(current_board);
          if (board) {
            document
              .querySelector("#cfpanel-select-workspace")
              .setAttribute("data-id", board.boards[0].id);
            canvas.loadFromJSON(
              board.boards[0].data,
              canvas.renderAll.bind(canvas)
            );
          }
        }
      }
    );
  }

  Coloris({
    parent: "#cfpanel",
    wrap: true,
    rtl: false,
    theme: "default",
    themeMode: "light",
    margin: 0,
    format: "hex",
    formatToggle: false,
    alpha: true,
    forceAlpha: false,
    swatchesOnly: false,
    focusInput: true,
    selectInput: false,
    clearButton: false,
    clearLabel: "Clear",
    closeButton: false,
    closeLabel: "Close",
    swatches: [
      "#264653",
      "#2a9d8f",
      "#e9c46a",
      "rgb(244,162,97)",
      "#e76f51",
      "#d62828",
      "navy",
      "#07b",
      "#0096c7",
      "#00b4d880",
    ],
    inline: false,
    defaultColor: "#000000",
    onChange: (color) => undefined,
  });

  let is_recording = false;

  let startRecording = document.querySelector(".cfPanelRecord");
  let downloadRecording = document.querySelector(".cfPanelDownload");

  startRecording.addEventListener("click", function () {
    if (is_recording) {
      cfPanel_recorder.stopRecording();
      chrome.storage.local.set({ screenRecording: false }, function () {
        console.log("Screen Recording is set to false"); // Fixed the log message
      });
      is_recording = false;
      document.querySelector(
        ".cfPanelRecord"
      ).innerHTML = `<i class="fas fa-record-vinyl" style="margin-right: 10px;"></i> Record`;
    } else {
      document.querySelector(
        ".cfPanelRecord"
      ).innerHTML = `<i class="fas fa-circle-stop" style="margin-right: 10px;"></i> Stop Recording`;
      cfPanel_recorder.init();
      cfPanel_recorder.startRecording();
      is_recording = true;
    }
  });

  downloadRecording.addEventListener("click", function () {
    cfPanel_recorder.downloadRecording();
  });

  let closeCFPanel = document.querySelector(".closeCFPanel");
  let canvas = new fabric.Canvas("whiteboard-canvas");

  fabric.Object.prototype.set({
    hasControls: true,
    hasBorders: true,
    borderColor: "black",
    cornerColor: "black",
    transparentCorners: false,
    cornerStyle: "circle",
  });

  fabric.Object.prototype.setControlVisible("mt", false);
  fabric.Object.prototype.setControlVisible("mb", false);
  fabric.Object.prototype.setControlVisible("ml", false);
  fabric.Object.prototype.setControlVisible("mr", true);
  fabric.Object.prototype.setControlVisible("tl", false);
  fabric.Object.prototype.setControlVisible("tr", false);
  fabric.Object.prototype.setControlVisible("bl", false);
  fabric.Object.prototype.setControlVisible("br", true);
  fabric.Object.prototype.setControlVisible("mtr", true);

  const drawingOptionsDiv = document.getElementById("cfpanel-drawing-options");

  document
    .getElementById("toggleDrawingMode")
    .addEventListener("click", function (e) {
      is_global_brush = true;
      document.querySelector("#cfp-path-color").value = brush_color;
      document.querySelector(
        "#cfpanel-toggle-brushcolor"
      ).innerHTML = `<i class="fas fa-circle" style="margin-right: 5px;color: ${brush_color}"></i> ${brush_color}`;

      closeAll();
      canvas.isDrawingMode = !canvas.isDrawingMode;

      if (canvas.isDrawingMode) {
        document.getElementById("toggleDrawingMode").classList.add("active");
        document.querySelector("#boardSettings").classList.add("disabled");
        document.querySelector("#newBoard").classList.add("disabled");
        document.querySelectorAll("#cfpanel-layer-add a").forEach((e) => {
          e.classList.add("disabled");
        });
      } else {
        document.getElementById("toggleDrawingMode").classList.remove("active");
        document.querySelector("#boardSettings").classList.remove("disabled");
        document.querySelector("#newBoard").classList.remove("disabled");
        document.querySelectorAll("#cfpanel-layer-add a").forEach((e) => {
          e.classList.remove("disabled");
        });
      }

      document.querySelector("#cfpanel-image-options").style.display = "none";
      document
        .querySelectorAll("#cfpanel-drawing-options .cfp-option")
        .forEach((item) => {
          item.style.display = "block";
        });

      if (canvas.isDrawingMode) {
        drawingOptionsDiv.style.display = "block";
      } else {
        drawingOptionsDiv.style.display = "none";
      }
    });

  document.getElementById("clearBoard").addEventListener("click", function (e) {
    if (!confirm("Are you sure you want to clear the board?")) return;

    canvas.clear();
  });

  document
    .querySelector("#cfpanel-delete-board")
    .addEventListener("click", async function (e) {
      if (!confirm("Are you sure you want to delete this board?")) return;

      deleteBoard(current_board);

      chrome.storage.local.get(["cfpanel-the-boards"], function (result) {
        const data = JSON.parse(JSON.stringify(result["cfpanel-the-boards"]));
        let index = data.findIndex((item) => item.id === current_board);
        data.splice(index, 1);
        chrome.storage.local.set({ ["cfpanel-the-boards"]: data });

        canvas.clear();

        document.querySelector("#cfpanel-board-settings").style.display =
          "none";
        document.querySelector("#cfpanel-workspaces").innerHTML = "";
        data.forEach((item) => {
          buildBoardItem(item);
        });
      });
    });

  document.querySelectorAll(".cfp-board-option").forEach((item) => {
    item.addEventListener("input", (e) => {
      chrome.storage.local.get(["cfpanel-the-boards"], function (result) {
        const data = result["cfpanel-the-boards"].find(
          (item) => item.id === parseInt(current_board)
        );

        data.name = document.getElementById("cfp-board-name").value;
        canvas.renderAll();

        document.querySelector("#cfpanel-workspace-title").textContent =
          data.name;

        chrome.storage.local.set(
          { "cfpanel-the-boards": result["cfpanel-the-boards"] },
          function () {}
        );
      });
    });
  });

  document
    .querySelector("#boardSettings")
    .addEventListener("click", function (e) {
      if (!e.target.classList.contains("disabled")) {
        closeAll();
        chrome.storage.local.get(["cfpanel-the-boards"], function (result) {
          document
            .querySelectorAll("#cfpanel-board-settings .cfp-option")
            .forEach((item) => {
              item.style.display = "block";
            });
          document.querySelector("#cfpanel-board-settings").style.display =
            "block";
        });
      }
    });

  document
    .getElementById("newBoard")
    .addEventListener("click", async function (e) {
      if (!e.target.classList.contains("disabled")) {
        closeAll();
        const name = "Untitled Board";
        const data = {};
        const bgColor = "#fff";
        const textColor = "#000";
        const brushColor = "#000";

        const board = await newBoard(
          name,
          data,
          bgColor,
          textColor,
          brushColor
        );

        document.querySelector("#cfp-board-name").value = "Untitled Board";
        document.querySelector("#cfpanel-workspace-title").textContent =
          "Untitled Board";

        document
          .querySelector("#cfpanel-select-workspace")
          .setAttribute("data-id", board.data[0].id);

        chrome.storage.local.get(["cfpanel-the-boards"], function (result) {
          result["cfpanel-the-boards"].push({
            id: board.data[0].id,
            name: name,
            bgColor: bgColor,
            textColor: textColor,
            brushColor: brushColor,
          });

          chrome.storage.local.set({
            "cfpanel-the-boards": result["cfpanel-the-boards"],
          });

          closeAll();
          canvas.clear();
          current_board = board.data[0].id;
        });
      }
    });

  whiteboard
    .querySelector("#cfpanel-layer-control")
    .querySelectorAll("a")
    .forEach((item, index) => {
      item.addEventListener("click", function (e) {
        e.preventDefault();
        let activeObject = canvas.getActiveObject();
        if (!activeObject) return;

        switch (index) {
          case 0:
            activeObject.sendToBack();
            break;
          case 1:
            activeObject.sendBackwards();
            break;
          case 2:
            activeObject.bringForward();
            break;
          case 3:
            activeObject.bringToFront();
            break;
        }

        canvas.renderAll();
      });
    });

  let optionsBar = document.querySelector("#cfpanel-layer-options");

  optionsBar.querySelectorAll("a").forEach((item, index) => {
    item.addEventListener("click", function (e) {
      e.preventDefault();
      let activeObject = canvas.getActiveObject();
      if (!activeObject) return;

      switch (index) {
        case 0: // Duplicate
          activeObject.clone(function (clonedObj) {
            canvas.discardActiveObject();

            if (clonedObj.type === "activeSelection") {
              let objects = clonedObj.getObjects();
              canvas.remove(clonedObj);

              objects.forEach(function (obj) {
                canvas.add(obj);
              });

              const newGroup = new fabric.ActiveSelection(objects, {
                canvas: canvas,
                left: clonedObj.left + 35,
                top: clonedObj.top + 35,
              });
              canvas.setActiveObject(newGroup);
            } else {
              clonedObj.set({
                left: clonedObj.left + 35,
                top: clonedObj.top + 35,
                active: false,
              });
              canvas.add(clonedObj);
              canvas.setActiveObject(clonedObj);
            }

            canvas.requestRenderAll();
          });
          break;
        case 1: // Delete
          var activeObjects = canvas.getActiveObjects(); // Get active objects
          if (activeObjects.length) {
            canvas.discardActiveObject(); // Discard current active selection
            activeObjects.forEach(function (object) {
              canvas.remove(object); // Remove each object
            });
          }
          canvas.requestRenderAll();
          break;
      }
    });
  });

  closeCFPanel.addEventListener("click", function () {
    whiteboard.querySelector("#cfpanel").style.display = "none";
    whiteboard.querySelector("#cfpanel-header").style.display = "none";
    whiteboardUnderlay.style.display = "none";
    whiteboardUnderlay.style.backgroundColor = "none";
    whiteboard.style.boxShadow = "none";
    document.querySelector(".closeCFPanel").style.display = "none";
    document.querySelector(".cfPanelRecord").style.display = "none";
    document.querySelector("#cfpanel-none-selected").style.display = "none";
    document.querySelector("#cfpanel-main-toolbar").style.display = "block";
    document.querySelector("#clearBoard").style.display = "block";
    document.querySelector("#boardSettings").style.display = "block";

    const positions = {
      zoom: canvas.getZoom(),
      top: canvas.viewportTransform[5],
      left: canvas.viewportTransform[4],
      board_id: current_board,
      board_name: document.querySelector("#cfpanel-workspace-title")
        .textContent,
    };

    chrome.storage.local.set({
      "cfpanel-saved-positions": JSON.stringify(positions),
    });

    setTimeout(() => {
      openCFPanel.style.display = "block";
    }, 550);

    panelNav.style.display = "none";
    document.body.style.overflow = "auto";
    whiteboard.style.top = "100%";
  });

  function canvasSettings() {
    canvas.backgroundColor = "#fff";
    canvas.freeDrawingBrush = new fabric.PencilBrush(canvas);
    canvas.freeDrawingBrush.decimate = 6;
    canvas.freeDrawingBrush.width = brush_size;
    canvas.freeDrawingBrush.color = brush_color;

    let isShiftKeyDown = false;

    canvas.on("mousedown", function (event) {
      isShiftKeyDown = event.e.shiftKey;
    });

    canvas.on("before:selection:created", function () {
      if (isShiftKeyDown) {
        canvas.discardActiveObject();
        isShiftKeyDown = false;
      }
    });

    canvas.on("selection:cleared", function () {
      closeAll();
    });

    canvas.on("selection:created", function (event) {
      closeAll();
      if (isShiftKeyDown) {
        canvas.discardActiveObject();
        isShiftKeyDown = false;
      } else {
        updateOption();
      }
    });

    canvas.on("selection:updated", function () {
      closeAll();
      updateOption();
    });

    let panning = false;

    canvas.on("mouse:down", function (opt) {
      // closeAll();
      if (opt.e.button === 4 || opt.e.shiftKey) {
        panning = true;
        this.setCursor("grabbing");
      }
    });

    canvas.on("mouse:up", function (opt) {
      panning = false;
      this.setCursor("default");
    });

    canvas.on("mouse:move", function (opt) {
      if (panning && (opt.e.button === 4 || opt.e.shiftKey)) {
        var delta = new fabric.Point(opt.e.movementX, opt.e.movementY);
        canvas.relativePan(delta);
        canvas.calcOffset();
      }
    });
    canvas.on("mouse:wheel", function (opt) {
      var delta = -opt.e.deltaY;
      var zoom = canvas.getZoom();
      zoom = zoom + delta * 0.005;

      if (zoom > 2) zoom = 2;
      if (zoom < 0.4) zoom = 0.4;
      canvas.zoomToPoint({ x: opt.pointer.x, y: opt.pointer.y }, zoom);
      canvas.calcOffset();
      opt.e.preventDefault();
      opt.e.stopPropagation();
    });

    const onChangeHandler = () => {
      if (!just_loaded_canvas) {
        debouncedSaveToServer();
      }
    };

    canvas.on("object:modified", onChangeHandler);
    canvas.on("object:added", onChangeHandler);
    canvas.on("object:removed", onChangeHandler);

    canvas.on("selection:cleared", function () {
      document.getElementById("cfpanel-main-toolbar").style.display = "flex";
      document.getElementById("cfpanel-edit-toolbar").style.display = "none";
      document.getElementById("cfpanel-options-toolbar").style.display = "none";
      document.querySelector("#cfpanel-image-options").style.display = "none";
    });
  }
  canvasSettings();

  function updateOption() {
    const textColor = canvas.getActiveObject().get("fill");
    whiteboard.querySelector("#cfp-text-color").value = textColor;
    document.querySelector(
      "#cfpanel-toggle-textcolor"
    ).innerHTML = `<i class="fas fa-circle" style="margin-right: 5px;color: ${textColor}"></i> ${textColor}`;
    whiteboard.querySelector("#fontSize").value = canvas
      .getActiveObject()
      .get("fontSize");
    whiteboard.querySelector(
      "#cfp-font-size h4"
    ).innerHTML = `Font Size: (${canvas.getActiveObject().get("fontSize")})`;

    whiteboard
      .querySelector("#cfpanel-weight-normal")
      .classList.remove("active");
    whiteboard.querySelector("#cfpanel-weight-bold").classList.remove("active");
    whiteboard.querySelector("#cfpanel-align-left").classList.remove("active");
    whiteboard
      .querySelector("#cfpanel-align-center")
      .classList.remove("active");
    whiteboard.querySelector("#cfpanel-align-right").classList.remove("active");
    whiteboard.querySelector("#cfpanel-font-sans").classList.remove("active");
    whiteboard.querySelector("#cfpanel-font-serif").classList.remove("active");

    const fontWeight = canvas.getActiveObject().get("fontWeight");
    const textAlign = canvas.getActiveObject().get("textAlign");
    const fontFamily = canvas.getActiveObject().get("fontFamily");

    if (fontWeight === "normal") {
      whiteboard
        .querySelector("#cfpanel-weight-normal")
        .classList.add("active");
    }

    if (fontWeight === "bold") {
      whiteboard.querySelector("#cfpanel-weight-bold").classList.add("active");
    }

    if (textAlign === "left") {
      whiteboard.querySelector("#cfpanel-align-left").classList.add("active");
    }

    if (textAlign === "center") {
      whiteboard.querySelector("#cfpanel-align-center").classList.add("active");
    }

    if (textAlign === "right") {
      whiteboard.querySelector("#cfpanel-align-right").classList.add("active");
    }

    if (fontFamily === "Roboto Flex") {
      whiteboard.querySelector("#cfpanel-font-sans").classList.add("active");
    }

    if (fontFamily === "Roboto Serif") {
      whiteboard.querySelector("#cfpanel-font-serif").classList.add("active");
    }

    let activeObject = canvas.getActiveObject();

    document.querySelector("#cfpanel-image-options").style.display = "none";
    document.querySelectorAll(".cfp-option").forEach((item) => {
      item.style.display = "none";
    });
    document.querySelector("#cfpanel-edit-toolbar").style.display = "flex";
    document.querySelector("#cfpanel-main-toolbar").style.display = "none";

    switch (activeObject.type) {
      case "activeSelection":
        fabric.Object.prototype.setControlVisible("mt", false);
        fabric.Object.prototype.setControlVisible("mb", false);
        fabric.Object.prototype.setControlVisible("ml", false);
        fabric.Object.prototype.setControlVisible("mr", false);
        fabric.Object.prototype.setControlVisible("tl", false);
        fabric.Object.prototype.setControlVisible("tr", false);
        fabric.Object.prototype.setControlVisible("bl", false);
        fabric.Object.prototype.setControlVisible("br", false);
        fabric.Object.prototype.setControlVisible("mtr", true);
        canvas.renderAll();
        break;
      case "path":
        is_global_brush = false;
        document.querySelector("#cfp-path-color").value = activeObject.stroke;
        document.querySelector(
          "#cfpanel-toggle-brushcolor"
        ).innerHTML = `<i class="fas fa-circle" style="margin-right: 5px;color: ${activeObject.stroke}"></i> ${activeObject.stroke}`;
        document.querySelector("#cfpanel-drawing-options").style.display =
          "block";

        document
          .querySelectorAll("#cfpanel-drawing-options .cfp-option")
          .forEach((e) => {
            e.style.display = "block";
          });

        document.querySelector("#cfp-path-size").style.display = "none";

        fabric.Object.prototype.setControlVisible("mt", false);
        fabric.Object.prototype.setControlVisible("mb", false);
        fabric.Object.prototype.setControlVisible("ml", false);
        fabric.Object.prototype.setControlVisible("mr", false);
        fabric.Object.prototype.setControlVisible("tl", false);
        fabric.Object.prototype.setControlVisible("tr", false);
        fabric.Object.prototype.setControlVisible("bl", false);
        fabric.Object.prototype.setControlVisible("br", true);
        fabric.Object.prototype.setControlVisible("mtr", true);
        canvas.renderAll();
        break;
      case "image":
        fabric.Object.prototype.setControlVisible("mt", false);
        fabric.Object.prototype.setControlVisible("mb", false);
        fabric.Object.prototype.setControlVisible("ml", false);
        fabric.Object.prototype.setControlVisible("mr", false);
        fabric.Object.prototype.setControlVisible("tl", false);
        fabric.Object.prototype.setControlVisible("tr", false);
        fabric.Object.prototype.setControlVisible("bl", false);
        fabric.Object.prototype.setControlVisible("br", true);
        fabric.Object.prototype.setControlVisible("mtr", true);
        document.querySelector("#cfpanel-options-toolbar").style.display =
          "block";
        document.querySelector("#cfpanel-image-options").style.display =
          "block";
        document
          .querySelectorAll("#cfpanel-image-options .cfp-option")
          .forEach((item) => {
            item.style.display = "block";
          });

        document.querySelector("#cfpanel-image-type").value = "local";
        document.getElementById("fileInput").value = "";
        document.getElementById("fileURLInput").value = "";
        document.getElementById("websiteURLInput").value = "";
        document.querySelector("#cfpanel-image-selected").style.display =
          "none";
        document.querySelector("#cfpanel-image-type-local").style.display =
          "block";
        document.querySelector("#cfpanel-image-type-url").style.display =
          "none";
        document.querySelector("#cfpanel-image-type-screenshot").style.display =
          "none";
        canvas.renderAll();

        break;
      case "textbox":
        document.querySelector("#cfpanel-options-toolbar").style.display =
          "block";
        document.getElementById("cfpanel-text-options").style.display = "block";
        document
          .querySelectorAll("#cfpanel-text-options .cfp-option")
          .forEach((item) => {
            item.style.display = "block";
          });

        fabric.Object.prototype.setControlVisible("mt", false);
        fabric.Object.prototype.setControlVisible("mb", false);
        fabric.Object.prototype.setControlVisible("ml", false);
        fabric.Object.prototype.setControlVisible("mr", true);
        fabric.Object.prototype.setControlVisible("tl", false);
        fabric.Object.prototype.setControlVisible("tr", false);
        fabric.Object.prototype.setControlVisible("bl", false);
        fabric.Object.prototype.setControlVisible("br", false);
        fabric.Object.prototype.setControlVisible("mtr", true);
        canvas.renderAll();

        break;
    }
  }

  window.addEventListener("resize", function () {
    canvas.setWidth(window.innerWidth);
    canvas.setHeight(window.innerHeight);
    canvas.calcOffset();
    canvas.renderAll();
  });

  function getViewportCenter(canvas) {
    var vpt = canvas.viewportTransform;

    return {
      left: (-vpt[4] + canvas.width / 2) / vpt[0],
      top: (-vpt[5] + canvas.height / 2) / vpt[3],
    };
  }

  whiteboard.querySelectorAll("#cfpanel-layer-add a").forEach((item, index) => {
    item.addEventListener("click", function (e) {
      e.preventDefault();

      if (!e.target.classList.contains("disabled")) {
        let newItem;

        const viewportCenter = getViewportCenter(canvas);

        switch (index) {
          case 0: // Text
            closeAll();
            newItem = new fabric.Textbox("Example", {
              fontFamily: "Roboto Flex",
              left: viewportCenter.left,
              top: viewportCenter.top,
              originX: "center",
              originY: "center",
              width: 300,
              splitByGrapheme: true,
              fill: default_text_color,
            });
            break;
          case 1: // Image
            closeAll();
            document.querySelector("#cfpanel-options-toolbar").style.display =
              "block";
            document.querySelector("#cfpanel-image-options").style.display =
              "block";
            document.querySelectorAll(".cfp-option").forEach((item) => {
              item.style.display = "none";
            });
            document
              .querySelectorAll("#cfpanel-image-options .cfp-option")
              .forEach((item) => {
                item.style.display = "block";
              });

            document.querySelector("#cfpanel-image-type").value = "local";
            document.getElementById("fileInput").value = "";
            document.getElementById("fileURLInput").value = "";
            document.getElementById("websiteURLInput").value = "";
            document.querySelector("#cfpanel-image-selected").style.display =
              "none";
            document.querySelector("#cfpanel-image-type-local").style.display =
              "block";
            document.querySelector("#cfpanel-image-type-url").style.display =
              "none";
            document.querySelector(
              "#cfpanel-image-type-screenshot"
            ).style.display = "none";
            return;
          case 2: // Shape
            newItem = new fabric.Rect({
              left: viewportCenter.left,
              top: viewportCenter.top,
              width: 100,
              height: 70,
              fill: "white",
              stroke: "gray",
              strokeWidth: 4,
              rx: 0,
              ry: 0,
              originX: "center",
              originY: "center",
              strokeUniform: true,
              objectCaching: false,
            });

            newItem.on("scaling", function () {
              this.set({
                width: this.width * this.scaleX,
                height: this.height * this.scaleY,
                scaleX: 1,
                scaleY: 1,
              });
            });
            break;
        }

        newItem.set({
          left: newItem.left - (newItem.width * newItem.scaleX) / 2,
          top: newItem.top - (newItem.height * newItem.scaleY) / 2,
        });

        canvas.add(newItem);
        canvas.setActiveObject(newItem);
        canvas.renderAll();
      }
    });
  });

  function disableDrawing() {
    canvas.isDrawingMode = false;
    document.querySelector("#toggleDrawingMode").classList.remove("active");
    document.querySelector("#cfpanel-drawing-options").style.display = "none";

    document.querySelector("#boardSettings").classList.remove("disabled");
    document.querySelector("#newBoard").classList.remove("disabled");
    document.querySelectorAll("#cfpanel-layer-add a").forEach((e) => {
      e.classList.remove("disabled");
    });
  }

  document
    .querySelector("#cfpanel-select-workspace")
    .addEventListener("click", function () {
      closeAll();

      chrome.storage.local.get(["cfpanel-the-boards"], function (result) {
        const boards = result["cfpanel-the-boards"];
        document.querySelector("#cfpanel-workspaces").innerHTML = "";
        boards.forEach((item) => {
          buildBoardItem(item);
        });
      });
      disableDrawing();
      document.querySelector("#cfpanel-workspaces").style.display = "block";
    });

  function closeAll() {
    document.querySelector("#cfpanel-drawing-options").style.display = "none";
    document.querySelector("#cfpanel-board-settings").style.display = "none";
    document.querySelector("#cfpanel-workspaces").style.display = "none";
    document.querySelector("#cfpanel-none-selected").style.display = "none";
    document.querySelector("#cfpanel-workspaces").style.display = "none";
    document.querySelector("#cfpanel-options-toolbar").style.display = "none";
    document.querySelector("#cfpanel-image-options").style.display = "none";
    document.querySelector("#cfpanel-edit-toolbar").style.display = "none";
    document.querySelectorAll(".cfp-option").forEach((item) => {
      item.style.display = "none";
    });
    document.querySelector("#cfpanel-main-toolbar").style.display = "block";
    document.querySelector("#boardSettings").style.display = "block";
  }

  function buildBoardItem(item) {
    const div = document.createElement("div");
    div.innerHTML = `<li><a href="#" data-id="${item.id}">${item.name}</a></li>`;
    document.querySelector("#cfpanel-workspaces").append(div);
    document.querySelectorAll("#cfpanel-workspaces a").forEach((item) => {
      item.addEventListener("click", async function (e) {
        e.preventDefault();
        just_loaded_canvas = true;
        setTimeout(() => {
          just_loaded_canvas = false;
        }, 2000);
        const id = this.getAttribute("data-id");
        current_board = id;

        document.querySelector("#cfpanel-workspace-title").innerHTML =
          this.innerHTML;

        document
          .querySelector("#cfpanel-select-workspace")
          .setAttribute("data-id", id);

        const board = await getBoard(id);

        document.querySelector("#cfp-board-name").value = board.boards[0].name;
        closeAll();
        canvas.dispose();
        canvas = new fabric.Canvas("whiteboard-canvas");
        canvasSettings();

        canvas.loadFromJSON(board.boards[0].data, function () {
          canvas.renderAll();
          canvas.discardActiveObject().renderAll();
        });
      });
    });
  }

  document.querySelector("#cfp-board-name").addEventListener("change", () => {
    debouncedSaveToServer();
  });

  async function saveToServer() {
    let id = document
      .querySelector("#cfpanel-select-workspace")
      .getAttribute("data-id");
    let json = canvas.toJSON(["url"]);
    let data = JSON.stringify(json);

    chrome.storage.local.get(["cfpanel-the-boards"], async function (result) {
      let boards = result["cfpanel-the-boards"];
      let board = boards.find((item) => item.id === parseInt(id));
      if (board) {
        document.querySelector("#cfpanel-saving").style.display = "block";
        const update = await updateBoard(board, data);
        if (!update.success) {
          alert("Uh oh, error saving...");
        }
      }
    });
  }

  whiteboard
    .querySelector("#cfp-text-color")
    .addEventListener("input", function () {
      let activeObject = canvas.getActiveObject();
      if (activeObject) {
        const textColor = this.value;
        document.querySelector(
          "#cfpanel-toggle-textcolor"
        ).innerHTML = `<i class="fas fa-circle" style="margin-right: 5px;color: ${textColor}"></i> ${textColor}`;
        activeObject.set("fill", textColor);
        canvas.renderAll();
      }
    });

  whiteboard
    .querySelector("#cfpanel-toggle-brushcolor")
    .addEventListener("click", function () {
      document.querySelector("#cfp-path-color").click();
    });

  document
    .querySelector("#cfpanel-image-type")
    .addEventListener("change", function () {
      const type = document.querySelector("#cfpanel-image-type").value;

      document.querySelector("#cfpanel-image-type-local").style.display =
        "none";
      document.querySelector("#cfpanel-image-type-url").style.display = "none";
      document.querySelector("#cfpanel-image-type-screenshot").style.display =
        "none";

      if (type === "local") {
        document.querySelector("#cfpanel-image-type-local").style.display =
          "block";
      } else if (type === "url") {
        document.querySelector("#cfpanel-image-type-url").style.display =
          "block";
      } else if (type === "screenshot") {
        document.querySelector("#cfpanel-image-type-screenshot").style.display =
          "block";
      }
    });

  whiteboard
    .querySelector("#cfp-path-color")
    .addEventListener("input", function () {
      document.querySelector(
        "#cfpanel-toggle-brushcolor"
      ).innerHTML = `<i class="fas fa-circle" style="margin-right: 5px;color: ${this.value}"></i> ${this.value}`;

      if (is_global_brush) {
        canvas.freeDrawingBrush.color = this.value;
        brush_color = this.value;
      } else {
        let activeObject = canvas.getActiveObject();
        if (activeObject && activeObject.type === "path") {
          activeObject.set("stroke", this.value);
        }
      }

      canvas.renderAll();
    });

  document
    .querySelector("#cfpanel-toggle-textcolor")
    .addEventListener("click", () => {
      document.querySelector("#cfp-text-color").click();
    });

  document
    .getElementById("cfpanel-font-sans")
    .addEventListener("click", function (e) {
      let activeObject = canvas.getActiveObject();
      if (activeObject && activeObject.type === "textbox") {
        e.target.classList.add("active");
        document
          .getElementById("cfpanel-font-serif")
          .classList.remove("active");
        activeObject.set({ fontFamily: "Roboto Flex" });
        canvas.renderAll();
      }
    });

  document
    .getElementById("cfpanel-font-serif")
    .addEventListener("click", function (e) {
      let activeObject = canvas.getActiveObject();
      if (activeObject && activeObject.type === "textbox") {
        e.target.classList.add("active");
        document.getElementById("cfpanel-font-sans").classList.remove("active");
        activeObject.set({ fontFamily: "Roboto Serif" });
        canvas.renderAll();
      }
    });

  document
    .getElementById("cfpanel-weight-normal")
    .addEventListener("click", function (e) {
      let activeObject = canvas.getActiveObject();
      if (activeObject && activeObject.type === "textbox") {
        e.target.classList.add("active");
        document
          .getElementById("cfpanel-weight-bold")
          .classList.remove("active");
        activeObject.set({ fontWeight: "normal" });
        canvas.renderAll();
      }
    });

  document
    .getElementById("cfpanel-weight-bold")
    .addEventListener("click", function (e) {
      let activeObject = canvas.getActiveObject();
      if (activeObject && activeObject.type === "textbox") {
        e.target.classList.add("active");
        document
          .getElementById("cfpanel-weight-normal")
          .classList.remove("active");
        activeObject.set({ fontWeight: "bold" });
        canvas.renderAll();
      }
    });

  document
    .getElementById("cfpanel-align-left")
    .addEventListener("click", function (e) {
      let activeObject = canvas.getActiveObject();
      if (activeObject && activeObject.type === "textbox") {
        e.target.classList.add("active");
        document
          .getElementById("cfpanel-align-center")
          .classList.remove("active");
        document
          .getElementById("cfpanel-align-right")
          .classList.remove("active");
        activeObject.set({ textAlign: "left" });
        canvas.renderAll();
      }
    });

  document
    .getElementById("cfpanel-align-right")
    .addEventListener("click", function (e) {
      let activeObject = canvas.getActiveObject();
      if (activeObject && activeObject.type === "textbox") {
        e.target.classList.add("active");
        document
          .getElementById("cfpanel-align-center")
          .classList.remove("active");
        document
          .getElementById("cfpanel-align-left")
          .classList.remove("active");
        activeObject.set({ textAlign: "right" });
        canvas.renderAll();
      }
    });

  document
    .getElementById("cfpanel-align-center")
    .addEventListener("click", function (e) {
      let activeObject = canvas.getActiveObject();
      if (activeObject && activeObject.type === "textbox") {
        e.target.classList.add("active");
        document
          .getElementById("cfpanel-align-left")
          .classList.remove("active");
        document
          .getElementById("cfpanel-align-right")
          .classList.remove("active");
        activeObject.set({ textAlign: "center" });
        canvas.renderAll();
      }
    });

  document.getElementById("fontSize").addEventListener("input", function (e) {
    let activeObject = canvas.getActiveObject();
    if (activeObject && activeObject.type === "textbox") {
      document.querySelector(
        "#cfp-font-size h4"
      ).innerHTML = `Font Size: (${this.value})`;
      activeObject.set({ fontSize: this.value });
      canvas.renderAll();
    }
  });

  document
    .querySelector("#cfpanel-choose-image")
    .addEventListener("click", () => {
      document.querySelector("#fileInput").click();
    });

  document.querySelector("#fileInput").addEventListener("change", (e) => {
    if (e.target.files[0]) {
      document.querySelector("#cfpanel-image-selected").style.display = "block";
      document.querySelector("#cfpanel-image-selected").textContent =
        e.target.files[0].name;
    }
  });

  // document.querySelector("#cfpanel-header").addEventListener("click", () => {
  //   closeAll();
  // });

  document.getElementById("pathSize").addEventListener("input", function (e) {
    document.querySelector(
      "#cfp-path-size h4"
    ).innerHTML = `Size: (${this.value})`;
    canvas.freeDrawingBrush.width = parseInt(this.value, 10);
    canvas.calcOffset();
    canvas.renderAll();
  });
}

function cfpanelInit() {
  chrome.storage.local.get(["cfpanel-the-boards"], function (result) {
    if (result["cfpanel-the-boards"] === undefined) {
      chrome.storage.local.set(
        {
          "cfpanel-the-boards": [],
        },
        function () {}
      );
    }
  });
}

function cfPanelInit() {
  const cfpanelport = chrome.runtime.connect({ name: "cfPanel" });

  cfpanelport.onMessage.addListener((message) => {
    if (message.action === "download" && message.url) {
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = message.url;
      a.download = "recorded.mp4";
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        document.body.removeChild(a);
        window.URL.revokeObjectURL(message.url);
      }, 100);
    }
  });

  cfpanelInit();

  WebFont.load({
    google: {
      families: ["Roboto+Flex", "Roboto+Serif"],
    },
    active: function () {
      fabric.util.clearFabricFontCache();

      chrome.storage.local.get(`cfSketch_user_data`, function (result) {
        let active = false;
        if (result["cfSketch_user_data"]) {
          cfpanel_userData = JSON.parse(result["cfSketch_user_data"]);
          let data = JSON.parse(result["cfSketch_user_data"]);
          active = data.active;
        }
        runCFPanel(active);
        clearInterval(styleguide_appcf);
      });
    },
  });
}

let styleguide_appcf = setInterval(() => {
  cfPanelInit();
}, 1500);

// turbo loaded
document.addEventListener("turbo:load", () => {
  cfPanelInit();
});
