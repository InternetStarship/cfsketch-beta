const cfPanel_recorder = {
  stream: null,
  mediaRecorder: null,
  recordedChunks: [],
  webcamStream: null,
  videoElement: null,

  init: async function () {
    if (!navigator.mediaDevices || !window.MediaRecorder) {
      alert("Your browser doesn't support the required APIs for recording.");
      return;
    }
  },

  startRecording: async function () {
    try {
      let webcamStream;
      let hasWebcam = true;

      try {
        webcamStream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });
        this.webcamStream = webcamStream;
      } catch (err) {
        hasWebcam = false;
        console.warn("No webcam detected.");
      }

      let audio = true;
      if (this.webcamStream) {
        audio = false;
      }

      const screenStream = await navigator.mediaDevices.getDisplayMedia({
        audio: audio,
        video: {
          displaySurface: "browser",
          frameRate: { ideal: 24, max: 30 },
          width: { ideal: 1920, max: 1920 },
          height: { ideal: 1080, max: 1080 },
        },
        selfBrowserSurface: "include",
        preferCurrentTab: true,
        surfaceSwitching: "exclude",
        systemAudio: "exclude",
      });
      this.screenStream = screenStream;

      screenStream.getVideoTracks()[0].onended = () => {
        console.log("Screen sharing stopped by the user.");
        this.stopRecording();
        document.querySelector(
          ".cfPanelRecord"
        ).innerHTML = `<i class="fas fa-record-vinyl" style="margin-right: 10px;"></i> Record`;
      };

      chrome.storage.local.set({ screenRecording: true }, function () {
        console.log("Screen Recording is set to true");
      });

      const combinedStream = new MediaStream([
        ...screenStream.getTracks(),
        ...(hasWebcam ? webcamStream.getTracks() : []),
      ]);
      this.stream = combinedStream;

      if (hasWebcam) {
        this.addWebCamVideo();
      } else {
        this.startMediaRecorder();
      }
    } catch (err) {
      alert("Error, was not able to start recording.");
      console.error("Error: " + err);
    }
  },

  addWebCamVideo: function () {
    videoElement = document.createElement("video");
    videoElement.id = "cfPanel-webcamVideo";
    videoElement.style.position = "fixed";
    videoElement.style.bottom = "10px";
    videoElement.style.right = "10px";
    videoElement.style.borderRadius = "50%";
    videoElement.style.width = "150px";
    videoElement.style.height = "150px";
    videoElement.style.background = "#000";
    videoElement.style.objectFit = "cover";
    videoElement.style.boxShadow = "0 0 10px rgba(0,0,0,0.5)";
    videoElement.style.cursor = "move";
    videoElement.style.zIndex = "999999";
    videoElement.srcObject = this.webcamStream;
    videoElement.muted = true;

    videoElement.addEventListener("mousedown", function (e) {
      let coords = { x: e.clientX, y: e.clientY };
      let moving = false;

      let initialRight = parseInt(window.getComputedStyle(videoElement).right);
      let initialBottom = parseInt(
        window.getComputedStyle(videoElement).bottom
      );

      function mouseMoveHandler(e) {
        moving = true;

        let deltaX = coords.x - e.clientX;
        let deltaY = coords.y - e.clientY;

        videoElement.style.right = `${initialRight + deltaX}px`;
        videoElement.style.bottom = `${initialBottom + deltaY}px`;
      }

      function mouseUpHandler(e) {
        document.removeEventListener("mousemove", mouseMoveHandler);
        document.removeEventListener("mouseup", mouseUpHandler);

        if (moving) {
          e.preventDefault();
        }
      }

      document.addEventListener("mousemove", mouseMoveHandler);
      document.addEventListener("mouseup", mouseUpHandler);
    });

    videoElement.play();

    document.body.appendChild(videoElement);
    this.videoElement = videoElement;

    videoElement.addEventListener("canplay", () => {
      videoElement.play();
      this.startMediaRecorder();
    });
  },

  startMediaRecorder: function () {
    this.mediaRecorder = new MediaRecorder(this.stream);

    this.mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        this.recordedChunks.push(event.data);
      }
    };

    this.mediaRecorder.onstop = () => {
      this.videoElement && this.videoElement.remove();
      this.downloadRecording();
      this.screenStream.getTracks().forEach((track) => track.stop());
    };

    this.mediaRecorder.start();
  },

  stopRecording: function () {
    if (this.mediaRecorder) {
      this.mediaRecorder.stop();

      if (this.webcamStream) {
        this.webcamStream.getTracks().forEach((track) => track.stop());
      }

      if (this.screenStream) {
        this.screenStream.getTracks().forEach((track) => track.stop());
      }

      if (this.stream) {
        this.stream.getTracks().forEach((track) => track.stop());
      }

      document.querySelectorAll("#cfPanel-webcamVideo").forEach((video) => {
        video.remove();
      });
      this.videoElement = null;

      chrome.storage.local.set({ screenRecording: false }, function () {
        console.log("Screen Recording is set to false"); // Fixed the log message
      });
    }
  },

  downloadRecording: function () {
    const blob = new Blob(this.recordedChunks, {
      type: "video/webm",
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.style.display = "none";
    a.href = url;
    a.download = "recorded.webm";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    }, 100);

    this.recordedChunks = [];
    this.stream = null;
    this.mediaRecorder = null;
    this.webcamStream = null;
    this.videoElement = null;
  },
};
